package com.model;

public enum Cliente {

	ANA,JUAN,CARLOS,PEPEELMAGO,DAVID,JERVING,EDUARDO
}
