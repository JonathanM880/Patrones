package com.inter;

public interface IPrecio {

	double getImporteTotal();
}
