package model;

import anotaciones.MiAnotacion;
import inter.Notificacion;

@MiAnotacion(name = "sms")
public class NotificacionSMS extends NotificacionDecorator{

	public NotificacionSMS(Notificacion noti) {
		super(noti);
		
	
	}
	//propia y particular de esta clase
	private void enviarSMS(String msg) {
		System.out.println("Se envia mensaje SMS " + msg);
		
	}
	
	@Override
	public void enviar(String msg) {
		super.enviar(msg); //lo que hace el objeto original
		enviarSMS(msg); //lo que le aumenté
	}

	
}
