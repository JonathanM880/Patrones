package fac;

import inter.Notificacion;

public interface Factory {
	void init(String pkgName);
	<T> T create(String name, Notificacion noti);
}