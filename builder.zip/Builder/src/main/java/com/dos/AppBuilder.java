package com.dos;

public class AppBuilder {

	public static void main(String[] args) {
		Libro lib = Libro.builder().id(23).titulo("Las mil una noches").idAutor(22).isbn("abc").build();
		System.out.println(lib);
		
		
	}
}
