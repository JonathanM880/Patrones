package com.dos;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
class Libro {

	private Integer id;
	private String titulo;
	private String isbn;
	private Integer idAutor;
	private Integer numPag;
	
}
