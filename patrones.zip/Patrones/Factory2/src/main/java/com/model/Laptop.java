package com.model;

import com.anotaciones.MiComponente;

@MiComponente(name = "laptop")
public class Laptop extends Computadora{
	{
		System.out.println("se creó una instancia de laptop");
	}
}
