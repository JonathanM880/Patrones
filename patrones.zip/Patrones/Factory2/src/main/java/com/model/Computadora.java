package com.model;

import com.anotaciones.MiComponente;


public class Computadora {

}
