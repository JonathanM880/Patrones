package com.model;

import com.anotaciones.MiComponente;

@MiComponente(name="prueba")
public class Prueba extends Computadora {

}
