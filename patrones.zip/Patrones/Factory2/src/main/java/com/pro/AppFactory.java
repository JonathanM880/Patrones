package com.pro;

import java.util.HashMap;
import java.util.Map;

import com.inter.Factory;
import com.inter.FactoryImpl;
import com.model.Computadora;

public class AppFactory {
	public static void main(String[] args) {
		Map<String, Class> componentes = new HashMap<String, Class>();
		Factory fac = new FactoryImpl();
		fac.init("com.model");
		
		Computadora pc = fac.create("pc");
		Computadora laptop = fac.create("laptop");
		Computadora server = fac.create("server");
	}
}
