package com.abs;

import com.model.Computadora.*;
import com.model.Laptop;
import com.model.Pc;
import com.model.Server;


public class FactoryImpl implements Factory{

	@Override
	public <T> T create(String name) {
		Object ret = null;
		switch(name) {
		case "pc":
		 ret = new Pc();
		 break;
		case "laptop":
			ret = new Laptop();
			 break;
		case "server":
			ret = new Server();
			 break;
			 
		default: System.out.println("no existe");
		}
		return (T)ret;
	}

}
