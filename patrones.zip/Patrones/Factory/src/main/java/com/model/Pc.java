package com.model;

import com.anotaciones.MiComponente;

@MiComponente(name = "Pc")
public class Pc extends Computadora{

	{
		System.out.println("se creó una instancia de pc");
	}
}
