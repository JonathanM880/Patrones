package main;

import modelo.Producto;
import servicios.ServicioP;
import servicios.ServicioProducto;
import servicios.Tienda;

public class main {
	public static void main(String[] args) {
		
		Tienda t = new Tienda();
		t.cargarProductos();
		t.mostrarProductos();
		t.comprarProducto(1);
		t.mostrarProductos();
		
	}
}
