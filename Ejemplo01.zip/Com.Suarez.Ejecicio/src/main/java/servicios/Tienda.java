package servicios;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import modelo.Bebida;
import modelo.Comida;
import modelo.Factory;
import modelo.FactoryImpl;
import modelo.Producto;
import modelo.Ropa;

public class Tienda {

	public static void cargarProductos() {
		ServicioP servicio = new ServicioP();
		Map<String, Class> componentes = new HashMap<String, Class>();
		Factory fac = new FactoryImpl();
		fac.init("modelo");
		
		Producto p1 = Producto.builder().cantidad(10).nombre("Coca-Cola").precio(1.25).build();
		Producto p2 = Producto.builder().cantidad(12).nombre("GokuChiquito").precio(12.5).build();
		Producto p3 = Producto.builder().cantidad(13).nombre("LibroMatematicaDiscreta").precio(15000000).build();
		Producto p4 = fac.create("comida");
		p4.builder().cantidad(11).precio(10.3).nombre("Arroz");
		Producto p5 = fac.create("bebida");
		p5.builder().cantidad(35).precio(11.7).nombre("Vino Tinto");
		Producto p6 = fac.create("ropa");
		p6.builder().cantidad(123).precio(23.85).nombre("Saco navideño");
		
		servicio.create(p1);
		servicio.create(p2);
		servicio.create(p3);
		servicio.create(p4);
		servicio.create(p5);
		servicio.create(p6);
	}

	public static void mostrarProductos() {
		System.out.println("-----------------------------------------------------------------");
		ServicioP servicio = new ServicioP();

		List<Producto> productos = servicio.listar();
		productos.forEach(System.out::println);
		System.out.println("-----------------------------------------------------------------");
	}

	public static void comprarProducto(int id) {
		ServicioP servicio = new ServicioP();

		Producto producto = servicio.read(id);

		if (producto != null && producto.getCantidad() > 0) {
			producto.setCantidad(producto.getCantidad() - 1);
			servicio.upgrade(producto);
			System.out.println("Se realizó la compra :3 ");
			System.out.println("-----------------------------------------------------------------");
		} else {
			System.out.println("Ya no quedan productos :v ");
		}
	}

}
