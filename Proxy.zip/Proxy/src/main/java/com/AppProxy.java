package com;

import com.dinamico.OperacionesFactory;
import com.impl.OperacionesNumeros;
import com.impl.OperacionesNumerosProxy;

public class AppProxy {

	public static void main(String[] args) {
		OperacionesNumerosProxy op = new OperacionesNumerosProxy();

		int res = op.sumar(3, 5);
		System.out.println(res);

		OperacionesNumeros on = OperacionesFactory.crearNumero(OperacionesNumeros.class);
		int sol = on.sumar(5, 8);
	}
}