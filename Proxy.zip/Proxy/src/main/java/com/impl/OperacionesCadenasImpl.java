package com.impl;

public class OperacionesCadenasImpl implements OperacionesCadenas {

	public String may(String s) {
		try {
			var res = s.toUpperCase();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return s;
	}
}
