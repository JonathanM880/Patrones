package com.impl;

public class OperacionesNumerosProxy implements OperacionesNumeros{
	
	OperacionesNumerosImpl target = new OperacionesNumerosImpl();

	@Override
	public int sumar(int x, int y) {
		// TODO Auto-generated method stub
		System.out.println("Añadiendo información de la suma antes de la ejecucion");
		int res = target.sumar(x,y);
		System.out.println("El objeto real está ejecutando la accion");
		return res;
	}

	@Override
	public int restar(int x, int y) {
		// TODO Auto-generated method stub
		System.out.println("Añadiendo información de la resta antes de la ejecucion");
		int res = target.restar(x,y);
		System.out.println("El objeto real está ejecutando la accion");
		return res;
	}

}
