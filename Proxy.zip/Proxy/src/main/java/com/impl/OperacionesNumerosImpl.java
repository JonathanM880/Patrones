package com.impl;

public class OperacionesNumerosImpl implements OperacionesNumeros{

	@Override
	public int sumar(int x, int y) {
		// TODO Auto-generated method stub
		return x+y;
	}

	@Override
	public int restar(int x, int y) {
		// TODO Auto-generated method stub
		return x-y;
	}

}
