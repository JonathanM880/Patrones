package com.impl;

public interface OperacionesCadenas {

	public String may(String s) ;
}
