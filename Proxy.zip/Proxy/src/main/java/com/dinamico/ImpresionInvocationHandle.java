package com.dinamico;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.Arrays;

public class ImpresionInvocationHandle implements InvocationHandler{

	private Object target;
	
	public ImpresionInvocationHandle(Object target) {
		this.target = target;
	}
	public ImpresionInvocationHandle() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public Object invoke(Object proxy, Method method, Object... args) throws Throwable { //puedo hacerle Object[] args o Object... args --parámetros variables
	System.out.printf("***** invocando a %s(%s)",method.getName(), Arrays.toString(args));
	long inicio = System.nanoTime();
	Object res = method.invoke(target, args);
	long t = System.nanoTime() - inicio;
	System.out.printf("Tiempo %.3f ms\n", t/1000.0f);
		return res;
	}

}
