package com.dinamico;

import java.lang.reflect.Proxy;
import com.impl.OperacionesNumeros;
import com.impl.OperacionesNumerosProxy;
import com.impl.OperacionesCadenas;
import com.impl.OperacionesCadenasImpl;

public class OperacionesFactory {

    private static Object crearProxy(Object target) {
        // Crear un proxy dinámico que delega las llamadas a los métodos del objeto real
        return Proxy.newProxyInstance(
            OperacionesFactory.class.getClassLoader(),
            target.getClass().getInterfaces(),
            new ImpresionInvocationHandle(target)
        );
    }

    public static <T> T crearNumero(Class<T> clase) {
        // Crear un proxy para la interfaz OperacionesNumeros
        OperacionesNumeros target = new OperacionesNumerosProxy();
        Object proxy = crearProxy(target);
        return clase.cast(proxy);
    }

    public static <T> T crearCadenas(Class<T> clase) {
        // Crear un proxy para la interfaz OperacionesCadenas
        OperacionesCadenas target = new OperacionesCadenasImpl();
        Object proxy = crearProxy(target);
        return clase.cast(proxy);
    }
}

