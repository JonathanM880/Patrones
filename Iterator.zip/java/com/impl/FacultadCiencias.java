package com.impl;

import java.util.LinkedList;

import com.inter.ICarreras;
import com.inter.IIterator;

public class FacultadCiencias implements ICarreras{

	private LinkedList<String> carreras;
	private int indice;
	
	public FacultadCiencias() {
		carreras = new LinkedList<String>();
		carreras.add("Matemática");
		carreras.add("Fisica");
		carreras.add("Ciencias de datos");
	}
	
	@Override
	public IIterator crearIterador() {
		
		return new CienciasIterator(carreras);
	}
	
	public class CienciasIterator implements IIterator {
		
		private LinkedList<String> carreras = new LinkedList<String>();
		private int indice;

	
		public CienciasIterator(LinkedList<String> carreras) {
			this.carreras = carreras;
			this.indice = 0;
		}
		@Override
		public void primerElemento() {
			// TODO Auto-generated method stub
			indice=0;
		}

		@Override
		public String next() {
			// TODO Auto-generated method stub
			return carreras.get(indice++);
		}

		@Override
		public Boolean finLista() {
			// TODO Auto-generated method stub
			return indice >=carreras.size();
		}

		@Override
		public String elementoActual() {
			// TODO Auto-generated method stub
			return carreras.get(indice);
		}

	}

}
