package com.impl;

import java.util.LinkedList;

import com.inter.ICarreras;
import com.inter.IIterator;

public class FacultadIngenieria implements ICarreras {

	private String[] carreras; // estructuras de datos diferentes

	public FacultadIngenieria() {
		carreras = new String[5];
		carreras[0] = "Civil";
		carreras[1] = "Computación";
		carreras[2] = "Sistemas de Información";
		carreras[3] = "Diseño Industrial";
		carreras[4] = "Mecánica";

	}

	@Override
	public IIterator crearIterador() {
		
		return new IngenieriaIterator(carreras);
	}

	public class IngenieriaIterator implements IIterator {

		private String[] carreras = new String[5];
		private int indice;

		public IngenieriaIterator(String[] carreras) {
			this.carreras = carreras;
			this.indice = 0;
		}

		@Override
		public void primerElemento() {
			// TODO Auto-generated method stub
			indice = 0;
		}

		@Override
		public String next() {
			// TODO Auto-generated method stub
			return carreras[indice++];
		}

		@Override
		public Boolean finLista() {
			// TODO Auto-generated method stub
			return indice >= carreras.length;
		}

		@Override
		public String elementoActual() {
			// TODO Auto-generated method stub
			return carreras[indice];
		}

	}

}
