package com;

import com.impl.FacultadCiencias;
import com.impl.FacultadCiencias.CienciasIterator;
import com.impl.FacultadIngenieria;
import com.inter.ICarreras;
import com.inter.IIterator;

public class AppIterator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ICarreras ciencias = new FacultadCiencias();
		IIterator cIterator = ciencias.crearIterador();
		//FacultadCiencias.CienciasIterator cienIt = ciencias.new CienciasIterator(ciencias.get(carreras));
		
		System.out.println("Carreras de la Faculta de Ciencias");
		print(cIterator);
		
		ICarreras ingenieria = new FacultadIngenieria();
		IIterator iIterator = ingenieria.crearIterador();
		System.out.println("--------------------------------------");
		System.out.println("Carreras de la Faculta de Ciencias");
		print(iIterator);
	}
	
	public static void print(IIterator iterator) {
	    while (!iterator.finLista()) {
	        System.out.println("iterator " + iterator.next());
	    }
	}


}
