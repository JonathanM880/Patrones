package com.inter;

public interface ICarreras {

	IIterator crearIterador();
}
