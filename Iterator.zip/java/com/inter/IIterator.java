package com.inter;

public interface IIterator {

	void primerElemento();
	String next();
	Boolean finLista();
	String elementoActual();
}
