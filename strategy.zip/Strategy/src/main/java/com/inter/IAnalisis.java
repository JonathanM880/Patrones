package com.inter;

public interface IAnalisis {

	void analizar();
}
