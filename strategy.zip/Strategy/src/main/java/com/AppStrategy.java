package com;

import com.model.AnalizarVirus;
import com.model.Tipo;

public class AppStrategy {

	
	
	public static void main(String[] args) {
		AnalizarVirus avaAntiAnalizarVirus = new AnalizarVirus(Tipo.completo);
		avaAntiAnalizarVirus.ejecutar();
	}
}
