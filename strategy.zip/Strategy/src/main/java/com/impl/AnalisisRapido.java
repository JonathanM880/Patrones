package com.impl;

import com.inter.IAnalisis;

public abstract class AnalisisRapido implements IAnalisis{

	@Override
	public void analizar() {
		
	}
	
	public abstract void iniciar();
	public abstract void saltar();
	public abstract void comprimir();
	
}
