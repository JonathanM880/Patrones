package com.impl;

public class AntivirusCompleto extends AnalisisCompleto {

	@Override
	public void iniciar() {
		// TODO Auto-generated method stub
		System.out.println("Inicia un antivirus completo");
		try {
			Thread.sleep(1700);
		} catch (InterruptedException e) {
			throw new RuntimeException("aaaa");
		}
	}

	@Override
	public void analizarMemoria() {
		// TODO Auto-generated method stub

		System.out.println("Analizando memoria ");

		try {
			Thread.sleep(1700);
		} catch (InterruptedException e) {
			throw new RuntimeException("aaaa");
		}
	}

	@Override
	public void analizarKeyLoggers() {
		// TODO Auto-generated method stub
		System.out.println("Analizando en busca de virus ");

		try {
			Thread.sleep(1700);
		} catch (InterruptedException e) {
			throw new RuntimeException("aaaa");
		}

	}

	@Override
	public void analizarRootKits() {
		// TODO Auto-generated method stub

		System.out.println("Analizando root kits xd ");

		try {
			Thread.sleep(1700);
		} catch (InterruptedException e) {
			throw new RuntimeException("aaaa");
		}
		System.out.println("Se concluyó el analisis en busca de virus");
	}

	@Override
	public void descomprimir() {
		// TODO Auto-generated method stub

		System.out.println("Descomprimiendo  ");

		try {
			Thread.sleep(1700);
		} catch (InterruptedException e) {
			throw new RuntimeException("aaaa");
		}
		
		System.out.println("");
	}

	@Override
	public void detener() {
		// TODO Auto-generated method stub

		System.out.println("*Se detiene ");

		try {
			Thread.sleep(1700);
		} catch (InterruptedException e) {
			throw new RuntimeException("aaaa");
		}
	}

}
