package com.impl;

public class AntivirusRapido extends AnalisisRapido {

	@Override
	public void iniciar() {
		// TODO Auto-generated method stub
		System.out.println("Inicia un antivirus rapido");
		try {
			Thread.sleep(1700);
		} catch (InterruptedException e) {
			throw new RuntimeException("aaaa");
		}
	}

	@Override
	public void saltar() {
		// TODO Auto-generated method stub
		System.out.println("saltando");
		try {
			Thread.sleep(1700);
		} catch (InterruptedException e) {
			throw new RuntimeException("aaaa");
		}
	}

	@Override
	public void comprimir() {
		// TODO Auto-generated method stub
		System.out.println("*comprime");
		try {
			Thread.sleep(1700);
		} catch (InterruptedException e) {
			throw new RuntimeException("aaaa");
		}
	}

}
