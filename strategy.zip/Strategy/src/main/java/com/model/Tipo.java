package com.model;

public enum Tipo {

	completo, rapido
}
